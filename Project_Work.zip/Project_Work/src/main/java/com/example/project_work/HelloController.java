package com.example.project_work;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class HelloController implements Initializable {
    FileChooser FileChooser = new FileChooser();
    Stage stage = new Stage();

    @FXML
    private Button btnNext;

    @FXML
    private ImageView imgModel;

    @FXML
    private TextField txtAddress;

    @FXML
    private TextField txtAge;

    @FXML
    private TextField txtHeight;

    @FXML
    private TextField txtMemberName;

    @FXML
    private TextField txtWeight;
    @FXML
    private Button btnExit;

    @FXML
    private Button btnOpen;

    @FXML
    private Button btnSave;

    @FXML
    private TextArea txtArea;

    @FXML
    void onExit(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    void onOpen(ActionEvent event) throws FileNotFoundException {
        FileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files (*.txt)", "*.txt"));
        File modelFile = FileChooser.showOpenDialog(new Stage());

        if (modelFile == null) {

        } else {
        txtArea.clear();
            Scanner inputFile = new Scanner(modelFile);
            while (inputFile.hasNext()) {
                txtArea.appendText(inputFile.nextLine());
                inputFile.close();
            }

        }
    }

    @FXML
    void onSave(ActionEvent event) throws FileNotFoundException {
        //adding extension filters to show only text files.
        FileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files(*.txt)","*.txt"));
        File modelFile =FileChooser.showSaveDialog(new Stage());
        if (modelFile==null){

        }else {
            PrintWriter outputFile = new PrintWriter(modelFile);//creating a new output file
            String enteredText = txtArea.getText();//everything typed in the textarea is stored in the new variable enterdtext.
        outputFile.println(enteredText); //the text in the text area should be displayed on my output file
        txtArea.clear();
        outputFile.close();
        }
    }
    @FXML
    void onNext(ActionEvent event) throws IOException {
        btnNext.getScene().getWindow().hide();//the button should hide the scene upon click
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("PopUpPage.fxml"));//and move to the new fxml page
        Scene scene = new Scene(fxmlLoader.load(), 650, 400);
        stage.setTitle("Today's Model");
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        FileChooser.setInitialDirectory(new File("C:\\Users\\hp\\Desktop\\EME Works"));
    }
}