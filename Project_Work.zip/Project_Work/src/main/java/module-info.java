module com.example.project_work {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.project_work to javafx.fxml;
    exports com.example.project_work;
}